from main import *

main()
